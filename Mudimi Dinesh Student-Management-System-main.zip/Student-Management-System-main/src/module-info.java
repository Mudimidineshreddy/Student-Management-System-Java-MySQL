/**
 * 
 */
/**
 * 
 */
module StudentManagementSystem {
	requires java.desktop;
	requires java.sql;
}