package pages;

public class Main {
	
	public static void main(String[] args) {
		LoginPage login = new LoginPage();
		login.setVisible(true);
	}

}
